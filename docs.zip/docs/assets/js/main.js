window.addEventListener('load', () => {
  let vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`)

  if ( window.matchMedia('(min-width: 1024px)').matches ) {
    let scrollbar_width = window.innerWidth - document.documentElement.clientWidth
    document.documentElement.style.setProperty('--scrollbarWidth', `${scrollbar_width}px`)
  }

  let header_height = document.querySelector('header').getBoundingClientRect().height
  document.documentElement.style.setProperty('--headerHeight', `${header_height}px`)

});


// /* Booking */
// let block_booking = document.querySelectorAll('.js-booking');
//
//
// block_booking.forEach(block => {
//
//   // Date Picker Input
//   let calendar_input = block.querySelector('.booking__calendar');
//   let booking_button = block.querySelector('.booking__button');
//
//
//   let booking_link = "", arrival_date = "", leave_date = "", room = "";
//
//
//   if ( calendar_input ) {
//
//     const picker = new Litepicker({
//       element: document.getElementById('checkin'),
//       elementEnd: document.getElementById('checkout'),
//       singleMode: false,
//       autoApply: true,
//       format: 'D MMMM',
//       lang: "ru-RU",
//       minDate: new Date(),
//       position: 'left auto',
//       numberOfMonths: 2,
//       numberOfColumns: 2,
//       showTooltip: false,
//       setup: (picker) => {
//         picker.on('selected', (date1, date2) => {
//           arrival_date = date2.format('DD/MM/YYYY')
//           leave_date = date2.format('DD/MM/YYYY')
//         });
//       },
//       plugins: ['mobilefriendly'],
//       mobilefriendly: {
//         breakpoint: 668,
//       },
//     });
//   }
//
//   // Create link from inputs
//   booking_button.addEventListener('click', (e)=>{
//
//     let link = "/booking/?&arrivalDate="+arrival_date+"&departureDate="+leave_date
//     console.log(link)
//
//     window.open(link, '_blank')
//   })
//
// })

Inputmask({
  mask: "+7 999 999 99 99",
  inputmode: 'numeric',
  showMaskOnFocus: true,
  "clearIncomplete": true,
  clearMaskOnLostFocus: true,
  greedy: false,
  nullable: true,
}).mask("input[type='tel']");


// function validateInputs(i) {
//     let error_text = parent.querySelector('.form__input-error')
//     let parent = i.closest('.form__input');
//
//     i.addEventListener('blur', ()=>{
//
//       if ( !i.checkValidity() ) {
//         i.setAttribute("invalid", '');
//         i.removeAttribute("valid", '');
//
//         parent ? parent.classList.add('error') : null;
//         error_text ? error_text.textContent = "Данное поле не заполнено или заполнено неверно" : "";
//       }
//       else {
//
//         i.removeAttribute("invalid", '');
//         i.setAttribute("valid", '');
//
//         parent ? parent.classList.remove('error') : null;
//         error_text ? error_text.textContent = "Данное поле не заполнено или заполнено неверно" : "";
//       }
//     })
// }

let inputs = document.querySelectorAll('input[name]:not([type="hidden"])');

inputs.forEach(input => {
  input.addEventListener('change', ()=>{
    validateInputs(input)
  })
})

function validateForm(form){
  form.reportValidity()
}


// /* Filters */
// function arrayRemove(arr, value) {
//   return arr.filter(function(ele){
//     return ele != value;
//   });
// }
//
// function findCommonElements(arr1, arr2) {
//   return arr1.some(item => arr2.includes(item))
// }
//
// /* Кнопка показать всё */
//
// let list_to_crop = document.querySelectorAll('.js-long_list')
//
// list_to_crop.forEach(list =>{
//   let button = list.querySelector('.js-toggle_content');
//
//   button.addEventListener('click', ()=>{
//     button.classList.toggle('active')
//     list.classList.toggle('active');
//
//     if (button.classList.contains('active')) {
//       button.textContent = 'Скрыть'
//       document.querySelector('.filters__more').style.display = 'flex'
//     } else {
//       button.textContent = 'Показать ещё'
//       document.querySelector('.filters__more').style.display = 'none'
//     }
//
//   })
//
// })
//
//
// select = document.querySelectorAll('.select')
// select.forEach(function(selectActive){
//   selectActive.addEventListener('change', (e) =>{
//     s = e.currentTarget
//     option = s.querySelectorAll('.option')
//     for(i=1; i < option.length; i++){
//       if(s.value === option[i].value){
//         s.classList.add('select-active')
//         s.dataset.target = option[i].value
//       }
//     }
//   })
// })
//
// let block_with_filters = document.querySelectorAll('.js-filtered_block');
//
// block_with_filters.forEach(block => {
//   let filter_block = block.querySelectorAll('.js-filters')
//
//   let targets_list = document.getElementById('content_to_sort');
//   let content_elements = targets_list.querySelectorAll('li[data-content]');
//   let reset_button = block.querySelectorAll('button[type=reset]');
//
//   filter_block.forEach(b => {
//     let inputs = b.querySelectorAll('[data-target]');
//     let data_attr = [];
//
//     inputs.forEach(i => {
//       if ( !inputs && !content_elements ) return;
//
//       i.addEventListener('change', (e)=> {
//         data_attr = []
//
//         let active_input = block.querySelectorAll(':scope .select-active, [data-target]:checked');
//
//         //console.log(active_input)
//
//         if ( active_input.length < 1 ) {
//           content_elements.forEach( el => {
//             el.classList.remove('hidden')
//           })
//         }
//         active_input.forEach(ai => {
//           let attr = ai.getAttribute('data-target')
//           data_attr.push(attr);
//         })
//
//         if ( data_attr.length < 1 ) return;
//
//         let cards_to_show = [];
//
//         content_elements.forEach(block => {
//           let data_content = block.getAttribute('data-content').split(',')
//           console.log('карточка:'+data_content)
//           console.log('кнопка:'+data_attr)
//
//           data_attr.forEach(attr => {
//             if ( block.getAttribute('data-content').includes(attr) ) {
//               console.log(block.getAttribute('data-content').includes(attr) )
//
//               cards_to_show.push(block)
//               block.classList.remove('hidden')
//             }else
//               block.classList.add('hidden')
//           })
//         })
//
//       })
//     })
//   })
//
//
//   // Reset filters
//
//   reset_button.forEach(button => {
//     button.addEventListener('click', ()=>{
//       content_elements.forEach( el => {
//         el.classList.remove('hidden')
//       })
//     })
//   })
//
// })



let map_places = document.getElementById('map')


  ymaps.ready(init);

  function init(){
    const map = new ymaps.Map('map', {
      center: [44.396631, 33.937235], // Москва
      zoom: 16
    });
    map.geoObjects
      .add(new ymaps.Placemark([ 44.397679, 33.936053], {
        iconCaption: 'Дримвуд',
      }, {
        iconColor: '#77b945',
        preset: 'islands#greenFamilyIcon',
      }))
  }

/* Кнопка скопировать номер */
//
// const copyToClipboard = (content, el) => {
//   if (window.isSecureContext && navigator.clipboard) {
//     navigator.clipboard.writeText(content);
//   } else {
//     unsecuredCopyToClipboard(content, el);
//   }
// };
//
// const unsecuredCopyToClipboard = (text, parentEl) => {
//   const textArea = document.createElement("textarea");
//   textArea.value=text;
//   parentEl.appendChild(textArea);
//   textArea.focus();
//   textArea.select();
//   try{
//     document.execCommand('copy')
//   }
//   catch(err){
//     console.error('Unable to copy to clipboard',err)
//   }
//   parentEl.removeChild(textArea)
// };
//
// let copy_buttons = document.querySelectorAll('.js_copy_phone')
//
// copy_buttons.forEach(b =>{
//   b.addEventListener('click', (e)=>{
//     let text = b.dataset.phone_number
//     copyToClipboard(text, e.currentTarget.parentNode)
//     b.textContent = "Скопировано!";
//     b.classList.add('is_copying')
//
//     setTimeout(()=>{
//       b.textContent = "Скопировать номер";
//       b.classList.remove('is_copying')
//     }, 1400)
//   })
// })


/* Открытие карточек */
if ( window.matchMedia('(max-width:1023px)').matches ){
  let header_dropdown = document.querySelectorAll('.is_dropdown')

  header_dropdown.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault()
      e.currentTarget.classList.toggle('is_open')
    })
  })
}

/* Скролл хедера */

let last_scroll = 0;

window.addEventListener('scroll', (e) => {

  document.documentElement.scrollTop > 0 ? document.querySelector('header').classList.add('scrolled') : document.querySelector('header').classList.remove('scrolled')

})

window.addEventListener('load', (e) => {

  document.documentElement.scrollTop > 0 ? document.querySelector('header').classList.add('scrolled') : document.querySelector('header').classList.remove('scrolled')

})


/* Скролл хедера мобилка */

// if ( window.matchMedia('(max-width:992px)').matches ) {
//
//   window.addEventListener('scroll', (e)=>{
//     let current_scroll = window.pageYOffset || document.documentElement.scrollTop;
//
//     current_scroll >= last_scroll && current_scroll ? document.querySelector('header').classList.add('scrolled-up') : document.querySelector('header').classList.remove('scrolled-up')
//
//     last_scroll = current_scroll
//   })
//
//   let submenu_button = document.querySelector('#js-open_panel')
//
//   submenu_button.addEventListener('click', ()=>{
//
//     submenu_button.nextElementSibling.classList.toggle('active')
//   })
// }



/* Навигация в хедере */

// if ( window.matchMedia('(min-width:993px)').matches ) {
//
//   let header_nav = document.querySelector('.header--nav')
//   let dropdown_button = header_nav.querySelector('.header--nav_item-more')
//   let dropdown_menu = header_nav.querySelector('.header--nav_item-more .is_dropdown--content .header_menu')
//
//   function isOverflown(element) {
//     return element.scrollWidth > element.clientWidth;
//   }
//
//   if ( isOverflown(header_nav) ) {
//     while( isOverflown(header_nav) ){
//
//       let last_link = header_nav.querySelector('.header--nav > div:last-of-type')
//       header_nav.removeChild(last_link)
//       dropdown_menu.appendChild(last_link)
//     }
//
//     dropdown_button.classList.remove('hidden')
//   }
//
// }

// opening menu

let opening_menu = document.querySelector('.header--burger')
let menu = document.querySelector('.header_menu')

opening_menu.addEventListener('click', (e) => {
      menu.classList.add('is_open')
  })

let  close_menu = document.querySelector('.header_menu-close')

close_menu.addEventListener('click', (e) => {
  menu.classList.remove('is_open')
})

PopupManager.register('popup_for_vacancy_form', {
    close_controls: true,
    is_block_scroll: false,
  },
  {
    on_close: (popup_element, params) => {
      popup_element.querySelector('form').reset();
    }
  }
);
PopupManager.register('popup_for_form', {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_close: (popup_element, params) => {
      popup_element.querySelector('form').reset();
    }
  }
);

PopupManager.register('popup_for_balloon',{
    is_block_scroll: true,
    close_controls: false,
  },{
    on_open: (popup_element, params) => {
      popup_element.querySelector('.balloon--image img').src = params.placemark.balloonImage;
      popup_element.querySelector('.balloon--title').textContent = params.placemark.balloonHeader;
      popup_element.querySelector('.balloon--text').textContent = params.placemark.balloonContent;
      popup_element.querySelector('a').href = params.placemark.balloonLink;
    },
  }
);

PopupManager.register('popup_for_scheme_menu', {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_close: (popup_element, params) => {
    }
  }
);

PopupManager.register('popup_for_hero_video', {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_open: (popup_element, params) => {
      popup_element.querySelector('video').play()
    },
    on_close: (popup_element, params) => {
      popup_element.querySelector('video').pause()
    }
  }
);

PopupManager.register('popup_for_scheme',{
    is_block_scroll: true,
    close_controls: false,
  },
  {
    on_open: (popup_element, params) => {
      let title = popup_element.querySelector('.js-popup_scheme--title'),
        subtitle = popup_element.querySelector('.js-popup_scheme--subtitle'),
        image_wrapper = popup_element.querySelector('.js-popup_scheme--image'),
        link = popup_element.querySelector('.js-popup_scheme--link');

      let scheme_object = SCHEME_PLACEMARKS[params.id] ? SCHEME_PLACEMARKS[params.id] : SCHEME_PLACEMARKS[0]

      title.textContent = scheme_object.title;
      subtitle.textContent = scheme_object.subtitle;

      link.href = scheme_object.link;

      for(let i = 0; i < scheme_object.images.length; i++) {
        let image = document.createElement('img');
        image.src = scheme_object.images[i]
        image.classList.add('popup__content-image-slide');
        image_wrapper.append(image)
      }

      activatePopupSchemeSlider(popup_element.querySelector('.js-popup_scheme--image'))

    },
    on_close: (popup_element, params) => {
      popup_element.querySelector('.js-popup_scheme--title').textContent = "";
      popup_element.querySelector('.js-popup_scheme--subtitle').textContent = "";
      popup_element.querySelector('.js-popup_scheme--image').innerHTML = "";
      popup_element.querySelector('.js-popup_scheme--link').href = ""
    }
  }
);


PopupManager.register('popup_menu',{
    is_block_scroll: true,
    close_controls: false,
  },
  {
    on_close: (popup_element, params) => {
      let accordions = popup_element.querySelectorAll('.js-openAccordion')
      accordions.forEach( a => {
        setTimeout(()=>{
          a.classList.contains('active') ? a.classList.remove('active') : false;
        }, 140)

      })
    }
  }
);

PopupManager.register('popup_for_confirmation',
  {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_open: (popup_element, params) => {
      let message_box = popup_element.querySelector('.popup__text');
      message_box.textContent = params.text;
    },
  }
);

PopupManager.register('popup_for_filters',
  {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_open: (popup_element, params) => {
      let block_to_clone = params.block;
      let block_content = block_to_clone.cloneNode(true);
      popup_element.querySelector('.popup__content').append(block_content);
    },
    on_close: (popup_element, open_params) => {
      setTimeout(()=>{
        popup_element.querySelector('.block--sections').remove()
      }, 100)
    }
  }
);

PopupManager.register('popup_for_room_advantages',
  {
    is_block_scroll: true,
    close_controls: true,
  },
  {
    on_open: (popup_element, params) => {

      let block_to_clone = params.block;
      let block_content = block_to_clone.cloneNode(true);
      popup_element.querySelector('.popup__content').append(block_content);

    },
    on_close: (popup_element, params) => {
      setTimeout(()=>{
        popup_element.querySelector('.room_content__advantages_list').remove()
      }, 100)
    }

  }
);

// Add event Listeners to open Popups
// Элемент (data-openpopup=""), где data-openpopup = popup.name

let open_popup_buttons = document.querySelectorAll('[data-openpopup]');

function activatePopupButtons(buttons){
  buttons.forEach(b => {

    b.addEventListener('click', (e)=>{
      e.preventDefault();

      if ( b.dataset.openpopup === "popup_for_room_advantages" ){
        let block_to_clone = b.previousElementSibling;
        if ( block_to_clone ) {
          PopupManager.open(b.dataset.openpopup, {block: block_to_clone})
        }
      }

      else if ( b.dataset.openpopup === "popup_for_scheme" ) {

        PopupManager.open(b.dataset.openpopup, {
          id: b.dataset.placemark_id ? b.dataset.placemark_id : '0'
        })
      }

      else if ( b.dataset.openpopup === "popup_for_filters") {
        let block_to_clone = b.parentElement;
        if (block_to_clone) {
          PopupManager.open(b.dataset.openpopup, {block: block_to_clone})
        }
      }

      else {
        PopupManager.open(b.dataset.openpopup);
      }

    })

  });
}

activatePopupButtons(open_popup_buttons)


/* Open popup after page loaded*/
window.addEventListener('load', ()=>{
  // PopupManager.open('popup_for_cookie')
  // PopupManager.open('popup_for_form')
})

/* Open popup after page loaded 1 time per session */
window.addEventListener('load', ()=>{
  // if ( localStorage.getItem('popState') !== 'shown' ) {
  //   active_manager.openPopup('popup_for_welcoming')
  //   localStorage.setItem('popState','shown')
  // }
})


/*
0 - Дефолтный компонент и пример для заполнения,
открывается если нет актуального id
*/

let SCHEME_PLACEMARKS = {
  0: {
    title: "Название объекта",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности и продающее его пользователю",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  1: {
    title: "Корпус Солнечный",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg","/assets/img/2.jpg","/assets/img/3.jpg"],
    link: "/",
  },
  2: {
    title: "Кинотеатр",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  3: {
    title: "Спортплощадка",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  4: {
    title: "Спортплощадка",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  5: {
    title: "Костровая площадка",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  6: {
    title: "Корпус Приморский",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  7: {
    title: "Спорткомплекс",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  8: {
    title: "СПИР",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  9: {
    title: "Корпус Космос",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  10: {
    title: "Бювет с мин.водой",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  11: {
    title: "Костровая площадка",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  12: {
    title: "Открытый басейн",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  13: {
    title: "Медцентр",
    subtitle: "Краткое описание объекта, раскрывающее его основные особенности",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  14: {
    title: "Костровая площадка",
    subtitle: "Бар с прохладительными напитками",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  15: {
    title: "Корпус Сокол",
    subtitle: "Раздевалки, туалеты, душевые",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  16: {
    title: "Костровая площадка",
    subtitle: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, sed.",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  17: {
    title: "Пляж",
    subtitle: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, sed.",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  18: {
    title: "Часовня",
    subtitle: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, sed.",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  19: {
    title: "Спортплощадка",
    subtitle: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, sed.",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },
  20: {
    title: "Спортплощадка",
    subtitle: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, sed.",
    description: "",
    schedule: "",
    images: ["/assets/img/1.jpg"],
    link: "/",
  },

}


/* Блок со схемой свг и плейсмарками */
let block_with_scheme = document.querySelectorAll('.content_scheme');


block_with_scheme.forEach(scheme => {
  let svg = scheme.querySelector('.scheme_svg');

  if ( svg ) {

    let placemarks = svg.querySelectorAll('[data-placemark]');

    placemarks.forEach(pm => {

      function getCoords(pm){
        return  pm.getBBox();
      }
      function getCoeff(){
        return  scheme.querySelector('svg').getBoundingClientRect().width / 1760
      }

      window.addEventListener('resize', ()=>{
        let coords = getCoords(pm)
        let coeff = getCoeff()
        tooltip.style.cssText = `left:${(coords.x*coeff)+(pm.getBBox().width / 2)}px;top:${coords.y*coeff}px;`
      })

      let tooltip = document.createElement('div');
      let tooltip_title = document.createElement('h3')

      scheme.querySelector('.scheme').append(tooltip);
      tooltip.append(tooltip_title)

      tooltip.classList.add('scheme--tooltip');

      let title;
      SCHEME_PLACEMARKS[pm.dataset.placemark_id] ? title = SCHEME_PLACEMARKS[pm.dataset.placemark_id].title : title = SCHEME_PLACEMARKS[0].title
      tooltip_title.textContent = title;

      let coords = getCoords(pm);
      let coeff = getCoeff();

      tooltip.style.cssText = `left:${(coords.x*coeff)+(pm.getBBox().width / 2)}px;top:${(coords.y*coeff)}px;`

      pm.addEventListener('mouseover', (e)=>{
        tooltip.classList.add('is_active')
      })

      pm.addEventListener('mouseleave', (e)=>{
        tooltip.classList.remove('is_active')
      })

    })


    // /* PanZoom for scheme */
    // const scheme_panzoom = new Panzoom(scheme.querySelector("#scheme_panzoom"), {
    //   maxScale: 2,
    //   step: 0.5,
    //   click: false,
    //   wheel: false,
    // });
    //
    // scheme_panzoom.toggleZoom()
    //
    // let zoom_in_button = scheme.querySelector('.js-zoom_in');
    // zoom_in_button.addEventListener('click', (e)=>{
    //   scheme_panzoom.zoomIn();
    //   checkZoom()
    // })
    //
    // let zoom_out_button = scheme.querySelector('.js-zoom_out')
    // zoom_out_button.addEventListener('click', (e)=>{
    //   scheme_panzoom.zoomOut();
    //   checkZoom()
    // })
    //
    //
    // function checkZoom(){
    //   !scheme_panzoom.canZoomOut() ? zoom_out_button.style.opacity = "0.3" : zoom_out_button.style.opacity = "1";
    //   !scheme_panzoom.canZoomIn() ? zoom_in_button.style.opacity = "0.3" : zoom_in_button.style.opacity = "1";
    // }
    // checkZoom();

  }
})


let block_tabs = document.querySelectorAll('.block_tabs')

block_tabs.forEach(block => {
  let placeMark = block.querySelectorAll('[data-placemark]')
  let filters = block.querySelectorAll('[data-content]'),
    items = block.querySelectorAll('[data-content_item]')
  if ( !filters && !items ) return;

  filters.forEach(f => {

    f.addEventListener('click', (e) =>{
      let data_attr = f.getAttribute('data-content')

      if (!data_attr) return;

      filters.forEach(el => {
        el !== f ? el.classList.remove('is_active') : el.classList.add('is_active')

      })

      items.forEach(el =>{
        el.dataset.content_item === data_attr ? el.classList.add('is_active') : el.classList.remove('is_active')
      })

      placeMark.forEach( p =>{
        p.dataset.placemark === data_attr ? p.classList.add('is_active')  : p.classList.remove('is_active')
      })

    })

  })
  filters[0].click()


  placeMark.forEach(f => {

    f.addEventListener('click', (e) =>{
      let data_attr = f.getAttribute('data-placemark')
      if (!data_attr) return;

      placeMark.forEach(el => {
        el.dataset.placemark !== f.dataset.placemark ? el.classList.remove('is_active') : el.classList.add('is_active')

      })

      items.forEach(el =>{
        el.dataset.content_item === data_attr ? el.classList.add('is_active') : el.classList.remove('is_active')
      })

      filters.forEach( p =>{
        p.dataset.content === data_attr ? p.classList.add('is_active')  : p.classList.remove('is_active')
      })

    })

  })
  filters[0].click()

})


Fancybox.bind('.gallery *[data-fancybox]', {
  infinite: false,
  groupAll: true
})


/* Page navigation Company */

let block_with_navigation = document.querySelectorAll(".js-page_navigation");

if ( block_with_navigation ) {

  let anchor_links = document.querySelectorAll('.js-anchor_link');

  anchor_links.forEach(link => {
    link.addEventListener("click", (event) => {
      event.preventDefault();

      let hash = event.currentTarget.hash.substring(1);
      let target = document.getElementById(hash);

      target.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    });
  });

  let callback = (entries, observer) => {
    entries.forEach(entry => {
      let link = document.querySelector("a[href='#"+ entry.target.id +"']");

      if ( entry.isIntersecting ) {
        link.classList.add("is_active")

      } else {
        link.classList.remove("is_active")
      }

    })
  }

  let observer = new IntersectionObserver(callback, {
    threshold: [0.5]
  });


  window.addEventListener("scroll", (event) => {

    anchor_links.forEach(link => {

      let hash = link.hash.substring(1)

      let section = document.getElementById(hash);
      if ( section ) observer.observe(section);
    });

  });
}

/* Слайдеры */
function calculateOffsetBefore(){
  if ( window.matchMedia('(min-width: 1024px)').matches ) {
    console.log(parseInt(window.getComputedStyle(document.documentElement).getPropertyValue('--g-80')))
    return Number(window.getComputedStyle(document.documentElement).getPropertyValue('--g-80'))
  } else if ( window.matchMedia('(max-width: 992px)').matches ){
    return Number(16)
  }
}

let banner_slider = document.querySelectorAll('.block_banner-group');

banner_slider.forEach(banner_sl => {

  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');

  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper-button-prev');
  slider_controls.append(swiper_nav_prev);

  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper-button-next');
  slider_controls.append(swiper_nav_next);

  if ( banner_sl.classList.contains('.block_banner-hero') ) {
    const hero_slider = new Swiper(banner_sl.querySelector('.block--wrapper'), {
      createElements: true,
      slideClass: 'banner',
      slidesPerView: 1,
      grabCursor: false,
      simulateTouch: true,
      allowTouchMove: true,
      centeredSlides: true,
      focusableElements: 'input, select, option, textarea, button, label, a',
      effect: 'slide',
      loop: true,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
    });

    if (hero_slider.slides.length <= 1) {
      hero_slider.navigation.nextEl.classList.add('hidden')
      hero_slider.navigation.prevEl.classList.add('hidden')
      hero_slider.disable()
    }
  }
  else {
    const hero_slider = new Swiper(banner_sl.querySelector('.block--wrapper'), {
      createElements: true,
      slideClass: 'banner',
      slidesPerView: 1,
      grabCursor: false,
      simulateTouch: true,
      allowTouchMove: true,
      centeredSlides: true,
      focusableElements: 'input, select, option, textarea, button, label, a',
      effect: 'slide',
      loop: true,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      spaceBetween: parseInt(window.getComputedStyle(banner_sl).getPropertyValue('padding'))
    });

    if (hero_slider.slides.length <= 1) {
      hero_slider.navigation.nextEl.classList.add('hidden')
      hero_slider.navigation.prevEl.classList.add('hidden')
      hero_slider.disable()
    }
  }

  banner_sl.append(slider_controls);
})



let swiper_block = document.querySelectorAll('.block_list-slider');

swiper_block.forEach(swiper_item => {

  let slides_per_view = 0, slides_per_view_pad = 0, slides_per_view_mobile = 1;

  switch( true ){
    case swiper_item.classList.contains('content_offers'):
      slides_per_view = 4;
      slides_per_view_pad = 4;
      break;
    // case swiper_item.classList.contains('content_accommodations'):
    //   slides_per_view = 2;
    //   slides_per_view_pad = 1.3;
    //   break;
    case swiper_item.classList.contains('content_area'):
      slides_per_view = 3;
      slides_per_view_pad = 3.3;
      break;
    case swiper_item.classList.contains('content_cards'):
      slides_per_view = 4;
      slides_per_view_pad = 3.3;
      break;
    case swiper_item.classList.contains('content_galleries'):
      slides_per_view = 4;
      slides_per_view_pad = 3.3;
      break;
    case swiper_item.classList.contains('content_events'):
      slides_per_view = 4 ;
      slides_per_view_pad = 4 ;
      break;
    case swiper_item.classList.contains('content_news'):
      slides_per_view = 3;
      slides_per_view_pad = 2.3;
      break;
    case swiper_item.classList.contains('content_blog'):
      slides_per_view = 3;
      slides_per_view_pad = 2.3;
      break;
    case swiper_item.classList.contains('content_articles'):
      slides_per_view = 3;
      slides_per_view_pad = 2.3;
      break;
    case swiper_item.classList.contains('content_personage'):
      slides_per_view = 4;
      slides_per_view_pad = 2.3;
      break;
    case swiper_item.classList.contains('content_restaurant'):
      slides_per_view = 2;
      slides_per_view_pad = 3.3;
      break;
    case swiper_item.classList.contains('content_partners'):
      slides_per_view = 4;
      slides_per_view_pad = 3.3;
      slides_per_view_mobile = 2.15
      break;
  }


  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');


  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper-button-prev');
  slider_controls.append(swiper_nav_prev);

  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper-button-next');
  slider_controls.append(swiper_nav_next);


  const swiper = new Swiper(swiper_item.querySelector('.block--elements'), {
    createElements: true,
    slideClass: 'card',
    slidesPerView: slides_per_view,
    grabCursor: true,
    simulateTouch: true,
    freeMode: false,
    allowTouchMove: true,
    uniqueNavElements: true,
    focusableElements: 'input, select, option, textarea, button, video, label, a, button, .card__image_slide',
    mousewheel: {
      forceToAxis: true,
    },
    navigation: {
      nextEl: swiper_nav_next,
      prevEl: swiper_nav_prev,
    },

    breakpoints: {
      240: {
        spaceBetween: 8,
        slidesPerView: slides_per_view_mobile,
        // slidesOffsetBefore: 16,
        // slidesOffsetAfter: 16,
      },
      768: {
        spaceBetween: 18,
        slidesPerView: slides_per_view_pad,
        // slidesOffsetBefore: 16,
        // slidesOffsetAfter: 16,
      },
      1024: {
        spaceBetween: 24,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        slidesPerView: slides_per_view,
      },
      1441:{
        spaceBetween: 40,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
      }

    },
  });


  if (swiper.slides.length <= 1) {
    swiper.navigation.nextEl.classList.add('hidden')
    swiper.navigation.prevEl.classList.add('hidden')
    swiper.disable()
  }

  swiper.el.append(slider_controls);

})


let gallery_swiper = document.querySelectorAll('.js-gallerySwiper');

gallery_swiper.forEach(gallery => {
  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');

  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper-button-prev');
  slider_controls.append(swiper_nav_prev);

  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper-button-next');
  slider_controls.append(swiper_nav_next);


  const swiper = new Swiper(gallery, {
    createElements: true,
    slidesPerView: 3,
    loop: true,
    // loopedSlides: 3,
    grabCursor: true,
    simulateTouch: true,
    freeMode: false,
    allowTouchMove: true,
    mousewheel: {
      forceToAxis: true,
    },
    effect: 'slide',
    initialSlide: 3,
    slideClass: 'gallery--item',
    navigation: {
      nextEl: swiper_nav_next,
      prevEl: swiper_nav_prev,
    },

    setWrapperSize: true,
    breakpoints: {
      320: {
        spaceBetween: 0
      },
      993: {
        spaceBetween: 40,
      }
    },
  });

  if (swiper.slides.length <= 1) {
    swiper.navigation.nextEl.classList.add('hidden')
    swiper.navigation.prevEl.classList.add('hidden')
    swiper.disable()
  }

  gallery.append(slider_controls);

})


if ( window.matchMedia("(max-width: 1023px)").matches ) {
  let content_advantages_icons = document.querySelectorAll('.content_advantages_icons')
  content_advantages_icons.forEach( block => {


    const swiper = new Swiper( block.querySelector('.block--elements'), {
      createElements: true,
      slideClass: 'advantages--item',
      slidesPerView: 1,
      grabCursor: true,
      simulateTouch: true,
      freeMode: false,
      spaceBetween: 8,
      allowTouchMove: true,
      uniqueNavElements: true,
      focusableElements: 'input, select, option, textarea, button, video, label, a, button, .card__image_slide',
      mousewheel: {
        forceToAxis: true,
      },
    });


    if (swiper.slides.length <= 1) {
      swiper.navigation.nextEl.classList.add('hidden')
      swiper.navigation.prevEl.classList.add('hidden')
      swiper.disable()
    }

  })
}

//
// if ( window.matchMedia("(max-width: 1023px)").matches ) {
//   let content_advantages = document.querySelectorAll('.content_advantages')
//   content_advantages.forEach( block => {
//
//     let slider_controls = document.createElement('div');
//     slider_controls.classList.add('slider_controls');
//
//     let swiper_nav_prev = document.createElement('div');
//     swiper_nav_prev.classList.add('swiper-button-prev');
//     slider_controls.append(swiper_nav_prev);
//
//     let swiper_nav_next = document.createElement('div');
//     swiper_nav_next.classList.add('swiper-button-next');
//     slider_controls.append(swiper_nav_next);
//
//     let swiper_pagination = document.createElement('div');
//     swiper_pagination.classList.add('swiper_pagination');
//     slider_controls.append(swiper_pagination);
//
//
//     const swiper = new Swiper( block.querySelector('.advantages_item_wrapper'), {
//       createElements: true,
//       slideClass: 'advantages--item',
//       slidesPerView: 1.2,
//       spaceBetween: 20,
//       grabCursor: true,
//       simulateTouch: true,
//       freeMode: false,
//       allowTouchMove: true,
//       uniqueNavElements: true,
//       focusableElements: 'input, select, option, textarea, button, video, label, a, button, .card__image_slide',
//       mousewheel: {
//         forceToAxis: true,
//       },
//       navigation: {
//         nextEl: swiper_nav_next,
//         prevEl: swiper_nav_prev,
//       },
//       pagination: {
//         type: 'progressbar',
//         el: swiper_pagination
//
//       },
//     });
//
//
//     if (swiper.slides.length <= 1) {
//       swiper.navigation.nextEl.classList.add('hidden')
//       swiper.navigation.prevEl.classList.add('hidden')
//       swiper.disable()
//     }
//
//     swiper.el.append(slider_controls);
//   })
// }
//
//
// function activatePopupSchemeSlider(block){
//     let slider_controls = document.createElement('div');
//     slider_controls.classList.add('slider_controls');
//
//     let swiper_pagination = document.createElement('div');
//     swiper_pagination.classList.add('swiper_pagination');
//     slider_controls.append(swiper_pagination);
//
//     let swiper_nav_prev = document.createElement('div');
//     swiper_nav_prev.classList.add('swiper-button-prev');
//     slider_controls.append(swiper_nav_prev);
//
//     let swiper_nav_next = document.createElement('div');
//     swiper_nav_next.classList.add('swiper-button-next');
//     slider_controls.append(swiper_nav_next);
//
//
//     const swiper = new Swiper( block , {
//       createElements: true,
//       slideClass: 'popup__content-image-slide',
//       slidesPerView: 1,
//       spaceBetween: 20,
//       grabCursor: true,
//       simulateTouch: true,
//       freeMode: false,
//       allowTouchMove: true,
//       uniqueNavElements: true,
//       mousewheel: {
//         forceToAxis: true,
//       },
//       navigation: {
//         nextEl: swiper_nav_next,
//         prevEl: swiper_nav_prev,
//       },
//       pagination: {
//         type: 'bullets',
//         el: swiper_pagination
//       },
//     });
//
//
//     if (swiper.slides.length <= 1) {
//       swiper.navigation.nextEl.classList.add('hidden')
//       swiper.navigation.prevEl.classList.add('hidden')
//       swiper.disable()
//     }
//
//     swiper.el.append(slider_controls);
// }


/* Кнопка показать еще для контента на странице номера */

let show_more_content_button = document.querySelectorAll('.js-show-content')

show_more_content_button.forEach(button => {

  button.addEventListener('click', (e)=>{

    let block_width_content = button.previousElementSibling;

    if ( block_width_content ) {
      block_width_content.classList.toggle('active')
      button.classList.toggle('active')

      button.classList.contains('active') ? button.textContent = "Скрыть" : button.textContent = "Показать ещё"
    }
  })
})

//
// let map = document.getElementById('map')
// let block_with_map = document.querySelector('.content_contacts')
//
// if ( block_with_map && map ) {
//   ymaps.ready(init);
//
//   function init() {
//     let map_settings = {};
//
//     if (  typeof SITE_MAP_SETTINGS === 'undefined' || SITE_MAP_SETTINGS === null ){
//       map_settings = {
//         coords: [44.843170, 33.604412],
//         title: "Заголовок",
//         text: "Описание вашего отеля",
//         link: "/",
//         image: "/assets/img/1.jpg",
//         mark: "",
//       };
//
//     } else {
//       map_settings = {...SITE_MAP_SETTINGS}
//     }
//
//
//     var map = new ymaps.Map("map", {
//         center: [44.843170, 33.604412],
//         zoom: 15,
//         controls: ['routeButtonControl']
//       }, {
//         searchControlProvider: 'yandex#search'
//       }),
//
//       placemark = new ymaps.Placemark(map_settings.coords, {
//           balloonContentHeader: "Жемчужина ",
//           balloonContent: "<a href='https://yandex.ru/maps/?ll=33.604466%2C44.842974&mode=routes&rtext=~44.843170%2C33.604412&rtt=auto&ruri=~ymapsbm1%3A%2F%2Fgeo%3Fdata%3DCgo0MDY2NjYyODI1EpMB0KDQvtGB0YHQuNGPLCDQoNC10YHQv9GD0LHQu9C40LrQsCDQmtGA0YvQvCwg0JHQsNGF0YfQuNGB0LDRgNCw0LnRgdC60LjQuSDRgNCw0LnQvtC9LCDRgdC10LvQviDQn9C10YHRh9Cw0L3QvtC1LCDQndCw0LHQtdGA0LXQttC90LDRjyDRg9C70LjRhtCwLCAyIgoN62oGQhVoXzNC&z=18.68' target='_blank'>проложить маршрут</a>",
//           // offset: [50, -30]
//         }, {
//           iconLayout: 'default#image',
//           iconImageHref: '/assets/img/icons/placemark.svg',
//           iconImageSize: [48, 56],
//           iconImageOffset: [-24, -56],
//           closeButton: false,
//           hideIconOnBalloonOpen: false,
//           balloonOffset: [100, 40]
//         }
//       );
//
//     map.geoObjects.add(placemark);
//
//     // Открываем балун на карте (без привязки к геообъекту).
//     placemark.balloon.open();
//
//     map.behaviors.disable('scrollZoom');
//
//
//   }
// }


/* Блок преимуществ  */
// if ( window.matchMedia("(min-width: 1023px)").matches ) {
//
  let block_with_advantages = document.querySelectorAll('.content_advantages')

  block_with_advantages.forEach(block => {

    let buttons = block.querySelectorAll('.advantages--item[data-filter]')
    let images = block.querySelectorAll('.advantages--image_item[data-filter]')

    buttons.forEach(button => {

      button.addEventListener('click', (e) => {
        let videos = block.querySelectorAll('video')
        videos.forEach(v => {
          v.pause()
        })

        buttons.forEach(b => {

          b !== e.currentTarget ? b.classList.remove('is_active') : b.classList.add('is_active')
        })
        images.forEach(i => {
          i.dataset.filter === button.dataset.filter ? i.classList.add('is_active') : i.classList.remove('is_active')

          if (i.querySelector('video')) {
            i.querySelector('video').play()
          }
        })

      })
    })

  })
// }

// /* Блок со схемой */
//
// let block_scheme = document.querySelectorAll('.content_scheme')
//
// block_scheme.forEach(block => {
//   let filters = block.querySelectorAll('[data-place]'),
//     items = block.querySelectorAll('[data-place_item]')
//   if ( !filters && !items ) return;
//
//   filters.forEach(f => {
//
//     f.addEventListener('click', (e) =>{
//       let data_attr = f.getAttribute('data-place')
//
//       if (!data_attr) return;
//
//       filters.forEach(el => {
//         el !== f ? el.classList.remove('is_active') : el.classList.add('is_active')
//       })
//
//       items.forEach(el =>{
//         el.dataset.place_item === data_attr ? el.classList.add('is_active') : el.classList.remove('is_active')
//       })
//
//       // block.dataset.active_road = data_attr
//     })
//
//   })
//
//   filters[0].click()
//
// })


/* Input type file */

function activateInputFiles(inputs){

  inputs.forEach(input => {

    let file_text = input.parentElement.querySelector(".js-changeDescriptionText")
    let changeFileButton = input.parentElement.querySelector(".js-clearFile")
    let text = file_text.textContent

    input.addEventListener("change", function(){
      file_text.innerHTML = "Загружен файл <strong>" + input.files.item(0).name +"</strong>"
      input.parentElement.classList.add("loaded");
    })

    changeFileButton.addEventListener("click", function(e){
      e.stopPropagation()
      e.preventDefault()

      input.value = ""
      input.parentElement.classList.remove("loaded")
      file_text.innerHTML = text
    })

  })

}

let inputs_file = document.querySelectorAll(".js-input_file")

activateInputFiles(inputs_file)

// Accordion

let accordionItems = document.querySelectorAll(".js-openAccordion");

accordionItems.forEach(item => {

  item.addEventListener("click", function(e){

    accordionItems.forEach(it => {
      if(it !== e.currentTarget) {
        it.classList.remove('is_open')
      }
    });
    item.classList.toggle('is_open')
  })
})


let reviews_block = document.querySelectorAll('.content_reviews')

reviews_block.forEach(block => {
  let reviews_video = block.querySelectorAll('.review--image')

  reviews_video.forEach(video_item => {
    let video = video_item.querySelector('video')
    if ( video ) {
      video.onplaying = function () {
        video_item.classList.add('is_playing')
      }
      video.onpause  = function () {
        video_item.classList.remove('is_playing')
      }

      video_item.addEventListener('click', (e)=>{
        video.paused || video.ended ?  video.play() : video.pause()
      })
    }
  })
})

